/**
 * app.js - Punto de entrada de la aplicación para GoDaddy cPanel (Phusion Passenger)
 * Portal ARVIC v1.1
 */

const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '.env') });

const app = require('./api/index.js');

const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
    console.log(`✅ Servidor Portal ARVIC ejecutándose en el puerto ${PORT} (https://app.grupoitarvic.com)`);
});

module.exports = app;
